# 品質監査指摘一覧

documentId: AUDIT-FINDINGS-001
version: 2026-06
category: quality_audit

## AUD-2025-018 仕様変更時の影響範囲記録不足
severity: major
仕様変更申請において、制御・試験・FMEA・サプライヤーへの影響が一貫して記録されていない。

## AUD-2024-041 例外条件の試験反映漏れ
severity: major
制御仕様に存在する例外条件が試験仕様へ反映されていない事例があった。

## AUD-2025-027 旧版参照
severity: minor
レビュー時に旧版仕様書を参照していた。回答・判定時に文書バージョンを必ず表示すること。
