# TCU-480 FMEA管理表 2026Q2

documentId: FMEA-2026Q2
version: 2026Q2
category: fmea

## FMEA-R12 センサー偏差による誤判定
severity: 8
occurrence: 4
detection: 3
rpn: 96
故障モード: センサー偏差により正常状態を異常と誤判定する。許容範囲 ±5℃ から ±3℃ への厳格化により再評価が必要。

## FMEA-R19 始動直後の誤アラーム
severity: 6
occurrence: 5
detection: 4
rpn: 120
低温始動直後のセンサー値不安定により誤アラームが発生する。現行対策は起動後5秒の判定保留。

## FMEA-R27 判定遅延による保護遅れ
severity: 9
occurrence: 3
detection: 4
rpn: 108
異常判定が遅れ、重大異常時の保護開始が遅延する。判定継続時間1,000msから800msへの変更により再評価が必要。

## FMEA-R33 アラーム境界不整合
severity: 7
occurrence: 3
detection: 5
rpn: 105
制御仕様と試験条件の境界値が一致せず、誤った合否判定が行われる。関連: 82℃重大判定。
