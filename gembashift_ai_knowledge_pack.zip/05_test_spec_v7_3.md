# TCU-480 試験条件一覧 v7.3

documentId: TEST-SPEC-73
version: 7.3
category: test_specification

## TC-12 低温始動試験
page: 34-37
priority: required
周囲温度 -20℃。ECU起動後5秒間は温度異常判定を保留すること。根拠: 制御仕様書 v3.4 §4.1.6。

## TC-18 校正後復帰試験
page: 42-45
priority: required
センサー校正後に通常判定へ正しく復帰すること。根拠: §4.3.2。

## TC-24 アラーム境界試験
page: 58-62
priority: required
77.9℃はアラームなし、78.0℃は警告、81.9℃は警告、82.0℃は重大アラーム。

## TC-31 応答性試験
page: 73-77
priority: required
異常状態800ms継続時の判定動作を確認する。旧条件1,000msから変更されたため再試験必須。

## TC-07 許容範囲逸脱試験
page: 19-22
priority: required
±3℃ の許容範囲を基準とする異常判定を確認する。

## TC-09 インターロック連動試験
page: 24-27
priority: recommended
重大異常時に出力制御停止へ遷移することを確認する。

## TC-15 試験運転モード例外試験
page: 39-41
priority: recommended
保守モード時に警告出力のみ抑制され、ログが継続することを確認する。

## TC-22 連続運転ログ試験
page: 49-52
priority: optional
90日保持要件の設定値を確認する。

## TC-40 回帰スモーク試験
page: 91-95
priority: recommended
温度系制御変更による横断影響を確認する。
