# サプライヤー照会回答集

documentId: SUPPLIER-QNA-001
version: 2026-06
category: supplier_qna

## SUP-ASK-2026-021 TS-14 精度保証確認
supplier: A社
status: pending
質問: -10℃から80℃で ±3℃ の精度保証が可能か。-20℃で起動後500ms以内に安定可能か。現行情報: TS-14 v5.1の標準保証値は±4℃、-20℃での最大安定時間は650ms。回答: 未回答。

## SUP-ASK-2025-118 低温応答確認
supplier: A社
status: answered
回答要旨: -20℃での代表安定時間は420ms。最大保証値は650ms。
